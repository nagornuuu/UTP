

/**
 *
 *  @author Nahornyi Andrii S24918
 *
 */

package zad1;


public interface Selector <T> {

    boolean select (T argument);

}
//Selector - z metodą select, zwracającą true jesli argument spełnia warunek zapisany w metodzoe i false w przeciwnym razie

