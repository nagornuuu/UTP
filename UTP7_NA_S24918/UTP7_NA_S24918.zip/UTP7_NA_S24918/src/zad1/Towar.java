package zad1;

class Towar {

    int id;
    int weight;

    Towar(int id, int weight) {
        this.id = id;
        this.weight = weight;
    }
}

